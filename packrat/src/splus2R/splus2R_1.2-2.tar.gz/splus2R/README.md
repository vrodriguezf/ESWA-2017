# splus2R
R package facilitating S-PLUS migration
