library(testthat)
library("TSdist") 
test_package("TSdist")

