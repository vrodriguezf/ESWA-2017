# ifultools
C Code for wmtsa, fractal and sapa R packages
